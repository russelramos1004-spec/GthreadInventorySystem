using Inventory.Core.Repositories;
using Inventory.Core.Services;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.Data.SqlClient;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

// register repositories and services (scoped). Pass connection string from configuration.
var conn = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddScoped(s => new SqlConnection(conn) );
builder.Services.AddScoped<UserRepository>();
builder.Services.AddScoped<CategoryRepository>();
builder.Services.AddScoped<ProductRepository>();
builder.Services.AddScoped<SupplierRepository>();
builder.Services.AddScoped<CustomerRepository>();
builder.Services.AddScoped<StockInRepository>();
builder.Services.AddScoped<StockOutRepository>();

builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<CategoryService>();
builder.Services.AddScoped<ProductService>();
builder.Services.AddScoped<SupplierService>();
builder.Services.AddScoped<CustomerService>();
builder.Services.AddScoped<StockInService>();
builder.Services.AddScoped<StockOutService>();

// Simple session auth provider
builder.Services.AddScoped<AuthenticationStateProvider, Inventory.Web.Auth.SessionAuthProvider>();
builder.Services.AddAuthorizationCore();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
app.UseStaticFiles();
app.UseRouting();
app.MapBlazorHub();
app.MapFallbackToPage("/_Host");
app.Run();
