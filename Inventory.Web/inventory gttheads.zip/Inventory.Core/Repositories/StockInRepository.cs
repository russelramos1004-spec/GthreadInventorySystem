using Inventory.Core.Models;
using Microsoft.Data.SqlClient;

namespace Inventory.Core.Repositories
{
    public class StockInRepository
    {
        private readonly SqlConnection _conn;
        public StockInRepository(SqlConnection conn) { _conn = conn; }

        public List<StockIn> GetAll()
        {
            var list = new List<StockIn>();
            using var cmd = new SqlCommand("SELECT * FROM StockIn ORDER BY Id DESC", _conn);
            if (_conn.State != System.Data.ConnectionState.Open) _conn.Open();
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                list.Add(new StockIn { Id=(int)r["Id"], ProductId=(int)r["ProductId"], SupplierId=(int)r["SupplierId"], Quantity=(int)r["Quantity"], TotalCost=(decimal)r["TotalCost"], Date=(System.DateTime)r["Date"] });
            }
            return list;
        }

        public bool Insert(StockIn s)
        {
            using var cmd = new SqlCommand("INSERT INTO StockIn (ProductId, SupplierId, Quantity, TotalCost) VALUES(@p,@s,@q,@t)", _conn);
            cmd.Parameters.AddWithValue("@p", s.ProductId);
            cmd.Parameters.AddWithValue("@s", s.SupplierId);
            cmd.Parameters.AddWithValue("@q", s.Quantity);
            cmd.Parameters.AddWithValue("@t", s.TotalCost);
            if (_conn.State != System.Data.ConnectionState.Open) _conn.Open();
            return cmd.ExecuteNonQuery() > 0;
        }
    }
}
