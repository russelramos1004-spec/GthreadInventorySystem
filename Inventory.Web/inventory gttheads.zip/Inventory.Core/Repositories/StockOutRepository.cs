using Inventory.Core.Models;
using Microsoft.Data.SqlClient;

namespace Inventory.Core.Repositories
{
    public class StockOutRepository
    {
        private readonly SqlConnection _conn;
        public StockOutRepository(SqlConnection conn) { _conn = conn; }

        public List<StockOut> GetAll()
        {
            var list = new List<StockOut>();
            using var cmd = new SqlCommand("SELECT * FROM StockOut ORDER BY Id DESC", _conn);
            if (_conn.State != System.Data.ConnectionState.Open) _conn.Open();
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                list.Add(new StockOut { Id=(int)r["Id"], ProductId=(int)r["ProductId"], CustomerId=(int)r["CustomerId"], Quantity=(int)r["Quantity"], TotalAmount=(decimal)r["TotalAmount"], Date=(System.DateTime)r["Date"] });
            }
            return list;
        }

        public bool Insert(StockOut s)
        {
            using var cmd = new SqlCommand("INSERT INTO StockOut (ProductId, CustomerId, Quantity, TotalAmount) VALUES(@p,@c,@q,@t)", _conn);
            cmd.Parameters.AddWithValue("@p", s.ProductId);
            cmd.Parameters.AddWithValue("@c", s.CustomerId);
            cmd.Parameters.AddWithValue("@q", s.Quantity);
            cmd.Parameters.AddWithValue("@t", s.TotalAmount);
            if (_conn.State != System.Data.ConnectionState.Open) _conn.Open();
            return cmd.ExecuteNonQuery() > 0;
        }
    }
}
