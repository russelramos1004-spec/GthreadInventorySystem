using Inventory.Core.Models;
using Microsoft.Data.SqlClient;

namespace Inventory.Core.Repositories
{
    public class SupplierRepository
    {
        private readonly SqlConnection _conn;
        public SupplierRepository(SqlConnection conn) { _conn = conn; }

        public List<Supplier> GetAll()
        {
            var list = new List<Supplier>();
            using var cmd = new SqlCommand("SELECT * FROM Suppliers ORDER BY Id DESC", _conn);
            if (_conn.State != System.Data.ConnectionState.Open) _conn.Open();
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                list.Add(new Supplier { Id=(int)r["Id"], Name=r["Name"].ToString() ?? "", Email=r["Email"].ToString() ?? "", Phone=r["Phone"].ToString() ?? "", Address=r["Address"].ToString() ?? "", CreatedAt=(System.DateTime)r["CreatedAt"] });
            }
            return list;
        }

        public bool Insert(Supplier s)
        {
            using var cmd = new SqlCommand("INSERT INTO Suppliers (Name, Email, Phone, Address) VALUES(@n,@e,@p,@a)", _conn);
            cmd.Parameters.AddWithValue("@n", s.Name);
            cmd.Parameters.AddWithValue("@e", (object?)s.Email ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@p", (object?)s.Phone ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@a", (object?)s.Address ?? DBNull.Value);
            if (_conn.State != System.Data.ConnectionState.Open) _conn.Open();
            return cmd.ExecuteNonQuery() > 0;
        }
    }
}
